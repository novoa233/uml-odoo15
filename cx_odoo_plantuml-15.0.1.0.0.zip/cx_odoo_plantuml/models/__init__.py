from . import ir_module, res_config_settings, ir_model
